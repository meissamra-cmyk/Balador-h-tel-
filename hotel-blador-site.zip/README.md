# Hôtel Blador — Concept de démonstration

Site statique HTML/CSS/JavaScript, multilingue FR/AR/EN.

Important: ce site est une proposition non officielle. Les visuels sont des photographies d’inspiration.
